/* ###################################################################
 **     Filename    : main.c
 **     Project     : Testing-FreeRTOS
 **     Processor   : MK64FN1M0VLL12
 **     Version     : Driver 01.01
 **     Compiler    : GNU C Compiler
 **     Date/Time   : 2020-05-19, 18:32, # CodeGen: 0
 **     Abstract    :
 **         Main module.
 **         This module contains user's application code.
 **     Settings    :
 **     Contents    :
 **         No public methods
 **
 ** ###################################################################*/
/*!
 ** @file main.c
 ** @version 01.01
 ** @brief
 **         Main module.
 **         This module contains user's application code.
 */
/*!
 **  @addtogroup main_module main module documentation
 **  @{
 */
/* MODULE main */


/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "Pins1.h"
#include "MCUC1.h"
#include "UTIL1.h"
#include "LED1.h"
#include "LEDpin1.h"
#include "BitIoLdd1.h"
#include "FRTOS1.h"
#include "WAIT1.h"
#include "LCD1.h"
#include "RW1.h"
#include "BitIoLdd13.h"
#include "LED2.h"
#include "LEDpin2.h"
#include "BitIoLdd14.h"
#include "LED3.h"
#include "LEDpin3.h"
#include "BitIoLdd15.h"
#include "Bit1.h"
#include "BitIoLdd16.h"
#include "Bit2.h"
#include "EN1.h"
#include "BitIoLdd4.h"
#include "BitIoLdd2.h"
#include "RS1.h"
#include "BitIoLdd5.h"
#include "BitIoLdd3.h"
#include "DB41.h"
#include "DB51.h"
#include "DB61.h"
#include "BitIoLdd12.h"
#include "BitIoLdd10.h"
#include "DB71.h"
#include "BitIoLdd11.h"
/* Including shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"
#include "PDD_Includes.h"
#include "Init_Config.h"


/* User includes (#include below this line is not maintained by Processor Expert) */
#include "FreeRTOS.h"
#include "task.h"
#include "croutine.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>


// Global Variables
uint32_t delay;
// RPI Task Variables
unsigned int motion_detected;
// UNO Task Variables
unsigned int rfid;
// LCD Task Variables
unsigned int alarm_counter;


enum LCD_States {init_lcd, lcd_display, lcd_wait, lcd_arm, lcd_armed, lcd_intrustion, lcd_unarm, lcd_unarmed, lcd_alert} lcd_state;
enum LEDState {INIT,L0} led_state;
enum UNOState {UINIT, U1} uno_state;
enum RPIState {RINIT, R0} rpi_state;


void LCD_Init(){
	lcd_state = init_lcd;
}

void LEDS_Init(){
	led_state = INIT;
}

void UNO_Init(){
	uno_state = UINIT;
}

void RPI_Init(){
	rpi_state = RINIT;
}


void LEDS_Tick(){
	//Actions
	switch(led_state){
	case INIT:
		break;
	case L0:
		if(lcd_state == init_lcd) {
			LED1_On();
		}
		else if(lcd_state == lcd_armed) {
			LED1_Off();
			LED2_On();
		}
		else if(lcd_state == lcd_intrustion) {
			LED2_Off();
			LED3_On();
		}
		else if(lcd_state == lcd_unarmed) {
			LED3_Off();
			LED1_On();
		}
		break;
	default:
		break;
	}
	//Transitions
	switch(led_state){
	case INIT:
		led_state = L0;
		break;
	case L0:
		led_state = L0;
		break;
	default:
		led_state = INIT;
		break;
	}
}
void RPI_Tick(){
	//Actions
	switch(rpi_state){
	case RINIT:
		break;
	case R0:
		if(Bit1_GetVal()) {
			motion_detected = 1;
		}
		else {
			if(!motion_detected) {
				motion_detected = 0;
			}
		}
		break;
	default:
		break;
	}
	//Transitions
	switch(rpi_state){
	case RINIT:
		rpi_state = R0;
		break;
	case R0:
		rpi_state = R0;
		break;
	default:
		rpi_state = RINIT;
		break;
	}
}

void UNO_Tick(){
	//Actions
	switch(uno_state){
	case UINIT:
		break;
	case U1:
		if(Bit2_GetVal()) {
			rfid = 1;
		}
		else {
			if(!rfid) {
				rfid = 0;
			}
		}
		break;
	default:
		break;
	}
	//Transitions
	switch(uno_state){
	case UINIT:
		uno_state = U1;
		break;
	case U1:
		uno_state = U1;
		break;
	default:
		uno_state = UINIT;
		break;
	}
}

void LCD_Tick() {
	// === Local Variables ===

	switch(lcd_state) {
	case init_lcd:
		LED1_On();
		if(alarm_counter == 1) {
			lcd_state = lcd_display;
			alarm_counter = 0;
		}
		alarm_counter++;
		break;
	case lcd_display:
		if(alarm_counter == 2) {
			lcd_state = lcd_wait;
			alarm_counter = 0;
		}
		alarm_counter++;
		for(delay = 0; delay < 900000; delay++); //delay
		break;
	case lcd_wait:
		lcd_state = lcd_wait;
		if(rfid) {
			lcd_state = lcd_arm;
			rfid = 0;
		}
		for(delay = 0; delay < 900000; delay++); //delay
		break;
	case lcd_arm:
		lcd_state = lcd_arm;
		if(rfid) {
			lcd_state = lcd_armed;
			rfid = 0;
		}
		for(delay = 0; delay < 900000; delay++); //delay
		break;
	case lcd_armed:
		lcd_state = lcd_armed;
		if(motion_detected) {
			lcd_state = lcd_intrustion;
		}
		break;
	case lcd_intrustion:
		if(alarm_counter == 2) {
			lcd_state = lcd_unarm;
			alarm_counter = 0;
		}
		alarm_counter++;
		for(delay = 0; delay < 1000000; delay++); //delay
		break;
	case lcd_unarm:
		lcd_state = lcd_unarm;
		if(rfid) {
			lcd_state = lcd_unarmed;
			rfid = 0;
			alarm_counter = 0;
		}
		if(alarm_counter == 10) {
			lcd_state = lcd_alert;
			alarm_counter = 0;
		}
		alarm_counter++;
		for(delay = 0; delay < 900000; delay++); //delay
		break;
	case lcd_unarmed:
		if(alarm_counter == 2) {
			lcd_state = lcd_arm;
			alarm_counter = 0;
		}
		alarm_counter++;
		motion_detected = 0;
		for(delay = 0; delay < 900000; delay++); //delay
		break;
	case lcd_alert:
		if(alarm_counter == 4) {
			lcd_state = lcd_arm;
			alarm_counter = 0;
			motion_detected = 0;
		}
		alarm_counter++;
		lcd_state = lcd_alert;
		break;
	}

	// State Actions
	switch(lcd_state) {
	case init_lcd:
		LCD1_Clear();
		LCD1_WriteLineStr(4, "123456789Initializing");
		LCD1_WriteLineStr(1, "Initializing");
		LCD1_WriteLineStr(2, "System ...");
		break;
	case lcd_display:
		LCD1_Clear();
		LCD1_WriteLineStr(4, "123456789Welcome to");
		LCD1_WriteLineStr(1, "Welcome to");
		LCD1_WriteLineStr(2, "Home Security!");
		break;
	case lcd_wait:
		LCD1_Clear();
		LCD1_WriteLineStr(4, "123456789To Set Password");
		LCD1_WriteLineStr(1, "To Set Password");
		LCD1_WriteLineStr(2, "Scan RFID ...");
		break;
	case lcd_arm:
		LCD1_Clear();
		LCD1_WriteLineStr(4, "123456789To Arm System");
		LCD1_WriteLineStr(1, "To Arm System");
		LCD1_WriteLineStr(2, "Re-scan RFID ...");
		break;
	case lcd_armed:
		LCD1_Clear();
		LCD1_WriteLineStr(4, "123456789System Armed --");
		LCD1_WriteLineStr(1, "System Armed --");
		LCD1_WriteLineStr(2, "On");
		break;
	case lcd_intrustion:
		LCD1_Clear();
		LCD1_WriteLineStr(4, "123456789System Intrusion");
		LCD1_WriteLineStr(1, "System Intrusion");
		break;
	case lcd_unarm:
		LCD1_Clear();
		LCD1_WriteLineStr(4, "123456789Scan RFID to");
		LCD1_WriteLineStr(1, "Scan RFID to");
		LCD1_WriteLineStr(2, "Un-arm");
		break;
	case lcd_unarmed:
		LCD1_Clear();
		LCD1_WriteLineStr(4, "123456789System Unarmed");
		LCD1_WriteLineStr(1, "System Unarmed");
		LCD1_WriteLineStr(2, "-- Off");
		break;
	case lcd_alert:
		LCD1_Clear();
		LCD1_WriteLineStr(4, "123456789Alert --");
		LCD1_WriteLineStr(1, "Alert --");
		LCD1_WriteLineStr(2, "Calling Police");
		break;
	}
}


void LcdSecTask() {
	LCD_Init();
	for(;;) {
		LCD_Tick();
		vTaskDelay(1000/portTICK_PERIOD_MS);
	}
}

void LedSecTask() {
	LEDS_Init();
	for(;;) {
		LEDS_Tick();
		vTaskDelay(500/portTICK_PERIOD_MS);
	}
}

void UnoSecTask() {
	UNO_Init();
	for(;;) {
		UNO_Tick();
		vTaskDelay(250/portTICK_PERIOD_MS);
	}
}

void RpiSecTask() {
	RPI_Init();
	for(;;) {
		RPI_Tick();
		vTaskDelay(250/portTICK_PERIOD_MS);
	}
}


void InitTasks() {
	xTaskCreate(LedSecTask,
			(signed portCHAR *)"LedSecTask",
			configMINIMAL_STACK_SIZE,
			NULL,
			4,
			NULL );
	xTaskCreate(LcdSecTask,
			(signed portCHAR *)"LcdSecTask",
			configMINIMAL_STACK_SIZE,
			NULL,
			3,
			NULL );
	xTaskCreate(UnoSecTask,
			(signed portCHAR *)"UnoSecTask",
			configMINIMAL_STACK_SIZE,
			NULL,
			2,
			NULL );
	xTaskCreate(RpiSecTask,
			(signed portCHAR *)"RpiSecTask",
			configMINIMAL_STACK_SIZE,
			NULL,
			1,
			NULL );
}


/*lint -save  -e970 Disable MISRA rule (6.3) checking. */
int main(void)
/*lint -restore Enable MISRA rule (6.3) checking. */
{
	/* Write your local variable definition here */

	/*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/


	PE_low_level_init();


	/*** End of Processor Expert internal initialization.                    ***/

	/* Write your code here */
	/* For example: for(;;) {} */

	// Initialize Tasks
	InitTasks();
	// Run Scheduler
	vTaskStartScheduler();
	//	}

	/*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
 ** @}
 */
/*
 ** ###################################################################
 **
 **     This file was created by Processor Expert 10.5 [05.21]
 **     for the Freescale Kinetis series of microcontrollers.
 **
 ** ###################################################################
 */
